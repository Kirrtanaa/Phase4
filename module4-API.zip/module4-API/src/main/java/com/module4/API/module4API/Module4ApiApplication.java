package com.module4.API.module4API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;

@SpringBootApplication
@EnableEurekaServer
@EnableZuulProxy
public class Module4ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Module4ApiApplication.class, args);
	}

}

