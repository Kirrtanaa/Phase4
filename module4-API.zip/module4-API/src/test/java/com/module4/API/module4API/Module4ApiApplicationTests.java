package com.module4.API.module4API;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Module4ApiApplicationTests {

	@Test
	public void contextLoads() {
	}

}
