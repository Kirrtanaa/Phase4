package com.module4.security.module4security;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller    
@RequestMapping(value= {"/main"}) // This means URL's start with /demo (after Application path)
public class SecurityController {
	
	
	@Autowired 
	private AuthorizationRepository Arep;
	
	@Autowired 
	private RoleRepository Rrep;
	
	@PostMapping(value= {"/addentry"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody String addNew (@Valid @RequestBody Authorization authority) {
		
		Arep.save(authority);
		return "Added";
	}

	@RequestMapping(value= {"/"}) 
	public @ResponseBody String addNewUser () {
//		Map<Integer,String> person = new HashMap<Integer,String>();
		
		Rrep.save(new Role("Admin"));
		Rrep.save(new Role("Mentor"));
		Rrep.save(new Role("User"));

		return "Saved";
	}
	
//	@GetMapping(value= {"/all"})
//	public @ResponseBody Iterable<Authorization> getAllUsers() {
//		return Arep.findAll();
//	}
}