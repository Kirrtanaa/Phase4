package com.module4.security.module4security;


import org.springframework.data.repository.CrudRepository;

import com.module4.security.module4security.Authorization;

public interface AuthorizationRepository extends CrudRepository<Authorization, Integer> {

}
