package com.module4.security.module4security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Module4SecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(Module4SecurityApplication.class, args);
	}

}
