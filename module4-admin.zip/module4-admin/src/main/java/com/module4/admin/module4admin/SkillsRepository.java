package com.module4.admin.module4admin;

import org.springframework.data.repository.CrudRepository;
import com.module4.admin.module4admin.Skills;

public interface SkillsRepository extends CrudRepository<Skills,Integer> {

}
