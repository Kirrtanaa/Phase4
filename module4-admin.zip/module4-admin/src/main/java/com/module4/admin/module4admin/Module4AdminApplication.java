package com.module4.admin.module4admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Module4AdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(Module4AdminApplication.class, args);
	}

}
