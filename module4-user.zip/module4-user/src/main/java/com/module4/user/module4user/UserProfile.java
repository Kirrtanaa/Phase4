package com.module4.user.module4user;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class UserProfile {

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private Integer myuserid;
 	
    private String firstname;
    
    private String lastname;
    
    private String username;
    
    private String password;

	public UserProfile() {
		super();
	}

	public UserProfile(String firstname, String lastname, String username, String password) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.password = password;
	}

	public Integer getMyuserid() {
		return myuserid;
	}

	public void setMyuserid(Integer myuserid) {
		this.myuserid = myuserid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

//	public UserTraining getUt() {
//		return ut;
//	}
//
//	public void setUt(UserTraining ut) {
//		this.ut = ut;
//	}
    
}
