package com.module4.mentor.module4mentor;

import javax.validation.Valid;

import org.springframework.data.repository.CrudRepository;

public interface MentorProfileRepository extends CrudRepository<MentorProfile, Integer> {



}

