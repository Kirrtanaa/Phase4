package com.module4.mentor.module4mentor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Module4MentorApplication {

	public static void main(String[] args) {
		SpringApplication.run(Module4MentorApplication.class, args);
	}

}
