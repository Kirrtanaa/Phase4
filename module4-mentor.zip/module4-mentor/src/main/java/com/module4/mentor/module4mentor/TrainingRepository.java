package com.module4.mentor.module4mentor;

import org.springframework.data.repository.CrudRepository;

public interface TrainingRepository extends CrudRepository<Training, Integer>{

}
